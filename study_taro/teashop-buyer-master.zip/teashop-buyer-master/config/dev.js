// eslint-disable-next-line import/no-commonjs
module.exports = {
  env: { NODE_ENV: '"development"' },
  defineConstants: {},
  weapp: {},
  h5: {}
}
