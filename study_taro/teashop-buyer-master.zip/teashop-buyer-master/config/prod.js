/* eslint-disable import/no-commonjs */
module.exports = {
  env: { NODE_ENV: '"production"' },
  defineConstants: {},
  weapp: {},
  h5: {}
}
